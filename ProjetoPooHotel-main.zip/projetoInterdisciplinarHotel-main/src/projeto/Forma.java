package projeto;

abstract public class Forma {
	abstract public void print();
}
